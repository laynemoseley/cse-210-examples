﻿static class Program
    {
        public static void Main()
        {
            var game = new ShapeLand();
            game.Play(); 
        }
    }

